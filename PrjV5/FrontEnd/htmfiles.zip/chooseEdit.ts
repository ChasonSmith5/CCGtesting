export function editABL(){
    var elemnt = document.getElementById("ablEdit") as HTMLElement;
    elemnt.style.display = 'block';
    var elemnt = document.getElementById("p1Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("p2Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("setEdit") as HTMLElement;
    elemnt.style.display = 'none';
}

export function editP1(){
    var elemnt = document.getElementById("p1Edit") as HTMLElement;
    elemnt.style.display = 'block';
    var elemnt = document.getElementById("ablEdit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("p2Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("setEdit") as HTMLElement;
    elemnt.style.display = 'none';
}

export function editP2(){
    var elemnt = document.getElementById("p2Edit") as HTMLElement;
    elemnt.style.display = 'block';
    var elemnt = document.getElementById("p1Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("setEdit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("setEdit") as HTMLElement;
    elemnt.style.display = 'none';
}

export function editSet(){
    var elemnt = document.getElementById("setEdit") as HTMLElement;
    elemnt.style.display = 'block';
    var elemnt = document.getElementById("p1Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("p2Edit") as HTMLElement;
    elemnt.style.display = 'none';
    var elemnt = document.getElementById("ablEdit") as HTMLElement;
    elemnt.style.display = 'none';
}