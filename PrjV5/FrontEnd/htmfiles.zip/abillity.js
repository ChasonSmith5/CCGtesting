export class abillityInfo {
    constructor() {
        this.abillityText = "";
        this.powerAdded = 0;
        this.typeAffected = 0;
        this.costAffected = 0;
        this.costIsAffected = false;
        this.typeIsAffected = false;
        this.powerIsAdded = false;
        this.abillityGlobalID = 0;
    }
}
